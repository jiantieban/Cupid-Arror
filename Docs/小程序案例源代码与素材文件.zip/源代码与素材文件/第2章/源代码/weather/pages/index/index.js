Page({
    data:{
       temp:"4",
       low:"-1℃",
       high:"10℃",
       type:"晴",
       city:"北京",
       week:"星期二",
       weather:"无持续风行 微风级"
    }
})