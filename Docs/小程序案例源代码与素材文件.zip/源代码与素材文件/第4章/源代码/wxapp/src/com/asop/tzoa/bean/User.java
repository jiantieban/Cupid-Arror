package com.asop.tzoa.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class User implements Serializable{
	private static final long serialVersionUID = -2271502857442585617L;

	private String id;
	private String userName;
	private String token;
	private String loginName;
	private String office;
	private Map<String, Object> extAttrMap = new HashMap<String, Object>();
	public User() {
		super();
	}
	public User(String id, String userName, String token, String loginName) {
		super();
		this.id = id;
		this.userName = userName;
		this.token = token;
		this.loginName = loginName;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getOffice() {
		return office;
	}
	public void setOffice(String office) {
		this.office = office;
	}
	public Map<String, Object> getExtAttrMap() {
		return extAttrMap;
	}
	public void setExtAttrMap(Map<String, Object> extAttrMap) {
		this.extAttrMap = extAttrMap;
	}
	
	
}
