package com.asop.tzoa.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
/**
 * ���ƶ����ṩjson����bean
 * @author bingmuzixing
 *
 */
public class AppDesk implements Serializable{
	private static final long serialVersionUID = 1765301641802369183L;
	private List<ApprovalAction> paramList = new ArrayList<ApprovalAction>();
	public List<ApprovalAction> getParamList() {
		return paramList;
	}

	public void setParamList(List<ApprovalAction> paramList) {
		this.paramList = paramList;
	}
}
