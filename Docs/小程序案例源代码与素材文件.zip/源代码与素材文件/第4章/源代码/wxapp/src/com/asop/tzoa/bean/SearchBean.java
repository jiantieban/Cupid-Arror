package com.asop.tzoa.bean;

import java.io.Serializable;

public class SearchBean implements Serializable{
	private static final long serialVersionUID = -3040223074138108674L;
	private String loginName; //�û���¼��
	private String appId;//ת������Ӧ��ID,��Ϊ��
	private int size; //��ѯ����
	private String order; //down or up
	private String date;//��������
	private String category;//�������� 1:����2���Ѱ� 3:���ģ�4���ճ�
	private String flag;  //�����ֶ�
	private String noExist;//������в���Ҫ�ٴ�����Щid�����м���,����
	
	public SearchBean() {
		super();
	}
	public SearchBean(String loginName, String appId, int size, String order, String date, String category,String noExist) {
		super();
		this.loginName = loginName;
		this.appId = appId;
		this.size = size;
		this.order = order;
		this.date = date;
		this.category = category;
		this.noExist=noExist;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getNoExist() {
		return noExist;
	}
	public void setNoExist(String noExist) {
		this.noExist = noExist;
	}
	
	
}
