package com.asop.tzoa.bean;

import java.io.Serializable;
import java.util.List;

public class ApprovalAction implements Serializable {
	private static final long serialVersionUID = 105459928145647972L;
	private String reqId;
	private String name;
	private int sum;
	private int code;
	private String desc;
	private String category;//操作类型 1:待办2：已办 3:待阅；4:已阅  5：日程
	private List<Approval> paramList;

	public String getReqId() {
		return reqId;
	}

	public void setReqId(String reqId) {
		this.reqId = reqId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSum() {
		return sum;
	}

	public void setSum(int sum) {
		this.sum = sum;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public List<Approval> getParamList() {
		return paramList;
	}

	public void setParamList(List<Approval> paramList) {
		this.paramList = paramList;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	
	
}
