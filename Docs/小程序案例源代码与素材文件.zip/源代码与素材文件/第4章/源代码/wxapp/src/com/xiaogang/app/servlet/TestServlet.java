package com.xiaogang.app.servlet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.asop.tzoa.bean.Approval;
import com.asop.tzoa.bean.ApprovalAction;

public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public TestServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String json = "{\"category\":\"1\",\"loginName\":\"wangyanshi\",\"order\":\"up\",\"size\":10,\"noExistId\":\"3641,3642,3624\"}";
		Map<String, Object> map =  (Map<String, Object>)JSON.parse(json);
		String category = String.valueOf(map.get("category"));
		String title = String.valueOf(map.get("title"));
		
		File file = new File("E:/json/gw.json");
		String encoding="utf-8";
		InputStreamReader read = new InputStreamReader(
        new FileInputStream(file),encoding);//���ǵ������ʽ
        BufferedReader bufferedReader = new BufferedReader(read);
        String lineTxt = null;
        String data = "";
        while((lineTxt = bufferedReader.readLine()) != null){
        	data = data + lineTxt;
        }
        read.close();
        System.out.println(data);
        JSONObject jsonObj = JSON.parseObject(data);  
        ApprovalAction approval = new ApprovalAction();
        approval.setCategory(category);
        approval.setCode(jsonObj.getIntValue("code"));
        approval.setDesc(jsonObj.getString("desc"));
        approval.setName(jsonObj.getString("name"));
        approval.setReqId(jsonObj.getString("reqId")); 
        String result = data;
        JSONArray jsonArray = jsonObj.getJSONArray("paramList");  
        List<Approval> list = new ArrayList<Approval>();
        List<Approval> links= JSON.parseArray(jsonArray.toJSONString(),Approval.class);
        if(category != null && !"".equals(category) && !"null".equals(category)){
        	 for(Approval app:links){
        		 if(title != null && !"".equals(title) && !"null".equals(title)){
        			 if(app.getTitle().contains(title) && app.getCategory().equals(category)){
            			 list.add(app); 
            		 }
        		 }else{
        			 if(app.getCategory().equals(category)){
        				 list.add(app); 
        			 }
        		 }
        	 }
        	 approval.setParamList(list);
        	 approval.setSum(list.size());
        	 result = JSON.toJSONString(approval);
        }else{
        	list = links;
        	approval.setParamList(list);
        	approval.setSum(list.size());
        	result = JSON.toJSONString(approval);
        }
        
	}

}
